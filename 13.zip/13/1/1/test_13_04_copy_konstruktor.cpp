// Datei: test_copy_konstruktor.cpp

#define TEST_FILE test_copy_konstruktor

#include "gip_mini_catch.h"

#include "CharListenKnoten.h"

TEST_CASE("Pruefung des Copy-Konstruktors CharListenKnoten::CharListenKnoten(const CharListenKnoten& orig)") {

	CharListenKnoten k1{'a'}, k2{'b'};
    k1.set_next(&k2);

    int old_count = CharListenKnoten::object_count;

    CharListenKnoten kc = k1; // Copy-Konstruktor Anwendung
    
    REQUIRE(CharListenKnoten::object_count == old_count + 1);

	REQUIRE(k1.get_data() == 'a');
    REQUIRE(k2.get_data() == 'b');
	REQUIRE(k1.get_next() == &k2);
	REQUIRE(k2.get_next() == nullptr);
    REQUIRE(k2.get_my_id() == k1.get_my_id() + 1);

	REQUIRE(kc.get_next() == nullptr);
    REQUIRE(kc.get_my_id() == k2.get_my_id() + 1);
}
