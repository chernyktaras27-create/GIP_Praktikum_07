#pragma once
class CharListenKnoten
{
protected:
    char data;
    CharListenKnoten* next;
    int my_id;

public:
    static int next_available_id;
    static int object_count;
    CharListenKnoten(char value, CharListenKnoten* nextPtr = nullptr)
        : data(value), next(nextPtr),my_id(next_available_id++)
    {
        object_count++;
    }
    // Copy-конструктор
    CharListenKnoten(const CharListenKnoten& other)
        : data(other.data), next(nullptr), my_id(next_available_id++)
    {
        object_count++;
    }
    // Assignment operator
    CharListenKnoten& operator=(const CharListenKnoten& other)
    {
        if (this != &other)
        {
            data = other.data;
            next = nullptr;
            // my_id і object_count не змінюємо
        }
        return *this;
    }
    ~CharListenKnoten(){
        object_count--;
    }

    // Getter
    char get_data() const { return data; }
    CharListenKnoten* get_next() const { return next; }
    int get_my_id() const { return my_id; }

    // Setter
    void set_data(char value) { data = value; }
    void set_next(CharListenKnoten* nextPtr) { next = nextPtr; }
};

void hinten_anfuegen(CharListenKnoten*& anker, const char wert);
void loesche_alle(CharListenKnoten*& anker);
CharListenKnoten* deep_copy(CharListenKnoten* orig);