// Datei: main.cpp 
#include <iostream> 
#define CATCH_CONFIG_RUNNER 
#include "gip_mini_catch.h" 
int main() 
{ 
Catch::Session().run(); 
system("PAUSE"); 
return 0; 
}