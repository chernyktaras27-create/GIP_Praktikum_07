#include "CharListenKnoten.h"
// ОБОВʼЯЗКОВА ініціалізація static-члена
int CharListenKnoten::next_available_id = 1;
int CharListenKnoten::object_count = 0;
void hinten_anfuegen(CharListenKnoten*& anker, const char wert)
{
    if (!anker) // список порожній
    {
        anker = new CharListenKnoten(wert);
        return;
    }

    // знаходимо останній вузол
    CharListenKnoten* aktuell = anker;
    while (aktuell->get_next() != nullptr)
    {
        aktuell = aktuell->get_next();
    }

    // додаємо новий вузол в кінець
    CharListenKnoten* neu = new CharListenKnoten(wert);
    aktuell->set_next(neu);
}
void loesche_alle(CharListenKnoten*& anker)
{
    if (!anker) return; // список порожній

    CharListenKnoten* aktuell = anker;
    while (aktuell != nullptr)
    {
        CharListenKnoten* naechster = aktuell->get_next(); // зберігаємо наступний вузол
        delete aktuell; // викликаємо деструктор
        aktuell = naechster; // переходимо до наступного
    }

    anker = nullptr; // оновлюємо зовнішню змінну
}
CharListenKnoten* deep_copy(CharListenKnoten* orig)
{
    if (!orig) return nullptr; // порожній список

    // створюємо перший вузол копії
    CharListenKnoten* kopie_start = new CharListenKnoten(orig->get_data());
    CharListenKnoten* aktuell_orig = orig->get_next(); // наступний вузол оригіналу
    CharListenKnoten* aktuell_kopie = kopie_start;     // останній вузол копії

    // копіюємо решту вузлів
    while (aktuell_orig != nullptr)
    {
        CharListenKnoten* neu = new CharListenKnoten(aktuell_orig->get_data());
        aktuell_kopie->set_next(neu); // додаємо новий вузол в кінець копії
        aktuell_kopie = neu;           // рухаємося вперед по копії
        aktuell_orig = aktuell_orig->get_next(); // рухаємося вперед по оригіналу
    }

    return kopie_start; // повертаємо початок нового списку
}