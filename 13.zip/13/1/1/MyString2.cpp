#include "MyString2.h"

// length
unsigned int MyString2::length() const
{
    unsigned int count = 0;
    CharListenKnoten* current = anker;

    while (current != nullptr) {
        count++;
        current = current->get_next();
    }

    return count;
}

// at
char MyString2::at(unsigned int pos) const
{
    CharListenKnoten* current = anker;
    unsigned int index = 0;

    while (current != nullptr) {
        if (index == pos) {
            return current->get_data();
        }
        current = current->get_next();
        index++;
    }

    return '\0';
}

// to_string
std::string MyString2::to_string() const
{
    std::string result;
    CharListenKnoten* current = anker;

    while (current != nullptr) {
        result += current->get_data();
        current = current->get_next();
    }

    return result;
}

// operator+
MyString2 MyString2::operator+(char c) const
{
    MyString2 result(*this);
    hinten_anfuegen(result.anker, c);
    return result;
}