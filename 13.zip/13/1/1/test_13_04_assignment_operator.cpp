// Datei: test_assignment_operator.cpp

#define TEST_FILE test_assignment_operator

#include "gip_mini_catch.h"

#include "CharListenKnoten.h"

TEST_CASE("Pruefung des Assignment Operators CharListenKnoten& CharListenKnoten::operator=(const CharListenKnoten& orig)") {

	CharListenKnoten k1{'a'}, k2{'b'};
    k1.set_next(&k2);

	CharListenKnoten k3{'c'}, k4{'d'};
    k3.set_next(&k4);
    int k3_my_id_old = k3.get_my_id();
    int k4_my_id_old = k4.get_my_id();

    int old_count = CharListenKnoten::object_count;

    k3 = k1; // Assignment Operator Anwendung
    
    REQUIRE(CharListenKnoten::object_count == old_count);

	REQUIRE(k1.get_data() == 'a');
    REQUIRE(k2.get_data() == 'b');
	REQUIRE(k1.get_next() == &k2);
	REQUIRE(k2.get_next() == nullptr);
    REQUIRE(k2.get_my_id() == k1.get_my_id() + 1);

    REQUIRE(k4.get_data() == 'd');
	REQUIRE(k4.get_next() == nullptr);
    REQUIRE(k4.get_my_id() == k4_my_id_old);

    REQUIRE(k3.get_data() == 'a');
	REQUIRE(k3.get_next() == nullptr);
    REQUIRE(k3.get_my_id() == k3_my_id_old);
}
