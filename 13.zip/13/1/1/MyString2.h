#pragma once
#include "CharListenKnoten.h"
#include <string>
class MyString2 {
private:
    CharListenKnoten* anker; // перший вузол рядка (nullptr, якщо порожній)

public:
    // Конструктор
    MyString2() : anker(nullptr) {}
    // Copy-конструктор
    MyString2(const MyString2& other) : anker(nullptr)
    {
        anker = deep_copy(other.anker);
    }

    // Assignment-оператор
    MyString2& operator=(const MyString2& other)
    {
        if (this != &other) {
            loesche_alle(anker);
            anker = deep_copy(other.anker);
        }
        return *this;
    }
    ~MyString2()
{
    loesche_alle(anker);
}
     // Конструктор з std::string
    MyString2(const std::string& s)
    : anker(nullptr) // спочатку рядок порожній
{
    for (size_t i = 0; i < s.length(); i++) {
        hinten_anfuegen(anker, s[i]); // додаємо символ у кінець списку
    }
}
   

   // Methoden
    unsigned int length() const;
    char at(unsigned int pos) const;
    std::string to_string() const;

    MyString2 operator+(char c) const;

    // Getter / Setter
    CharListenKnoten* get_anker() const { return anker; }
    void set_anker(CharListenKnoten* a) { anker = a; }
};
