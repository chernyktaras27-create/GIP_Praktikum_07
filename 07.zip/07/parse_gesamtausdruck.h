// Datei: parse_gesamtausdruck.h

#pragma once

#include <string>

void parse_gesamtausdruck(std::string input, std::size_t &pos, bool &error_found);
