// Datei: test_schritt_1_expect.cpp

#define TEST_FILE test_schritt_2_match

#include <string>

#include "gip_mini_catch.h"

#include "match.h"

TEST_CASE("match() sieht den erwarteten Buchstaben") {
	std::size_t pos = 0;
	bool error_found = false;

	pos = 0;
	error_found = false;
	match('a', "abc", pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == 1);

	pos = 1;
	error_found = false;
	match('b', "abc", pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == 2);

	pos = 2;
	error_found = false;
	match('c', "abc", pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == 3);
}



TEST_CASE("match() sieht einen anderen als den erwarteten Buchstaben") {
	std::size_t pos = 0;
	bool error_found = false;

	pos = 0;
	error_found = false;
	match('c', "abc", pos, error_found);
    REQUIRE(error_found == true);
    REQUIRE(pos == 0);

	pos = 1;
	error_found = false;
	match('x', "abc", pos, error_found);
    REQUIRE(error_found == true);
    REQUIRE(pos == 1);

	pos = 2;
	error_found = false;
	match('a', "abc", pos, error_found);
    REQUIRE(error_found == true);
    REQUIRE(pos == 2);
}

TEST_CASE("match() bei schon leerem Input") {
	std::size_t pos = 0;
	bool error_found = false;

	match('a', "", pos, error_found);
    REQUIRE(error_found == true);
    REQUIRE(pos == 0);
}

TEST_CASE("match() verändert den error_found Indikator nicht") {
	std::size_t pos = 0;
	bool error_found = true;

	match('a', "abc", pos, error_found);
    REQUIRE(error_found == true);
    REQUIRE(pos == 1);
}
