// Datei: match.h

#pragma once

#include <string>

void match(char c, std::string input, std::size_t &pos, bool &error_found);
