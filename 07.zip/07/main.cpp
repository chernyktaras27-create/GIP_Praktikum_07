// Datei: schritt_8_parse_gesamtausdruck.cpp

#define CATCH_CONFIG_RUNNER
#include "gip_mini_catch.h"

#include <iostream>
#include <cassert>

#include "parse_gesamtausdruck.h"

int main()
{
    Catch::Session().run();

    std::cout << "\n\n\n"
              << "Ein positiver Testlauf: \n";

    std::size_t pos = 0;
    bool error_found = false;
    std::string input = "(4>3)U2<7.";

    parse_gesamtausdruck(input, pos, error_found);

    assert(error_found == false);
    assert(pos == input.length());

	
    std::system("PAUSE");
    return 0;
}

