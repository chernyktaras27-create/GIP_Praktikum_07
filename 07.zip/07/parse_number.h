// Datei: parse_number.h

#pragma once

#include <string>

void parse_number(std::string input, std::size_t &pos, bool &error_found);
