// Datei: parse_ausdruck.cpp

#include <iostream>
#include <string>

#include "parse_ausdruck.h"

#include "expect.h"
#include "match.h"
#include "parse_term.h"

void parse_ausdruck(std::string input, std::size_t &pos, bool &error_found)
{
	std::cout << "Betrete parse_ausdruck()" << std::endl;

    parse_term(input, pos, error_found);

	std::cout << "Verlasse parse_ausdruck()" << std::endl;
}
