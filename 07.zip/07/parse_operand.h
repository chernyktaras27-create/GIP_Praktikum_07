// Datei: parse_operand.h

#pragma once

#include <string>

void parse_operand(std::string input, std::size_t &pos, bool &error_found);
