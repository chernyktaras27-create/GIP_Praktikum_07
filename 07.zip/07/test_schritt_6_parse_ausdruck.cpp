// Datei: test_schritt_6_parse_ausdruck.cpp

#define TEST_FILE schritt_6_parse_ausdruck

#include <string>

#include "gip_mini_catch.h"

#include "parse_ausdruck.h"

TEST_CASE("parse_ausdruck() bekommt einen korrekt gebildeten Ausdruck") {
    std::size_t pos = 0;
    bool error_found = false;
    std::string input = "";

    pos = 0;
    error_found = false;
    input = "2";
    parse_ausdruck(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == input.length());

    pos = 0;
    error_found = false;
    input = "1U2";
    parse_ausdruck(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == input.length());

    pos = 0;
    error_found = false;
    input = "1U2O3";
    parse_ausdruck(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == input.length());

    pos = 0;
    error_found = false;
    input = "3O1<2";
    parse_ausdruck(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == input.length());

    pos = 0;
    error_found = false;
    input = "4>3O1<2";
    parse_ausdruck(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == input.length());
}

TEST_CASE("parse_ausdruck() bekommt einen inkorrekt gebildeten Ausdruck") {
    std::size_t pos = 0;
    bool error_found = false;
    std::string input = "";

    pos = 0;
    error_found = false;
    input = "2U";
    parse_ausdruck(input, pos, error_found);
    REQUIRE(error_found == true || pos != input.length());
    // Keine genaue Lokalisation der Fehlerstelle ...
    // REQUIRE(pos == 2);

    pos = 0;
    error_found = false;
    input = "1UO2";
    parse_ausdruck(input, pos, error_found);
    REQUIRE(error_found == true || pos != input.length());
    // Keine genaue Lokalisation der Fehlerstelle ...
    // REQUIRE(pos == 4);
}

TEST_CASE("parse_ausdruck() bei leerem Input") {
    std::size_t pos = 0;
    bool error_found = false;

    parse_ausdruck("", pos, error_found);
    REQUIRE(error_found == true);
    REQUIRE(pos == 0);
}

TEST_CASE("parse_ausdruck() veraendert bei korrekt gebildetem Ausdruck den error_found Indikator nicht") {
    std::size_t pos = 0;
    bool error_found = false;
    std::string input = "1U2";

    // Der "input" an sich ist ein korrekt gebildeter Ausdruck ...
    parse_ausdruck(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == input.length());

    pos = 0;
    error_found = true; // ... sei schon true aus vorherigem fehlgeschlagenen Parsen
    parse_ausdruck(input, pos, error_found);
    REQUIRE(error_found == true);
    REQUIRE(pos == input.length());
}
