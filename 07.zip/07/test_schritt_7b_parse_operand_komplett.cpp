// Datei: test_schritt_7b_parse_operand_komplett.cpp

#define TEST_FILE schritt_7b_parse_operand_komplett

#include <string>

#include "gip_mini_catch.h"

#include "parse_operand.h"

TEST_CASE("parse_operand() bekommt einen korrekt gebildeten Operanden") {
    std::size_t pos = 0;
    bool error_found = false;
    std::string input = "";

    pos = 0;
    error_found = false;
    input = "4>3";
    parse_operand(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == 1);

    pos = 2; // ... auch an Position "mittendrin" parsen
    error_found = false;
    input = "4>3<7";
    parse_operand(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == 3);

    pos = 2; // ... auch an Position "mittendrin" parsen
    error_found = false;
    input = "4>3";
    parse_operand(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == input.length());

    // Neue Testfälle ...

    pos = 0;
    error_found = false;
    input = "(1U2)";
    parse_operand(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == input.length());

    pos = 0;
    error_found = false;
    input = "(1<2O3)";
    parse_operand(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == input.length());

    pos = 0;
    error_found = false;
    input = "(1<2O4>3)";
    parse_operand(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == input.length());
}

TEST_CASE("parse_operand() bekommt einen inkorrekt gebildeten Operanden") {
    std::size_t pos = 0;
    bool error_found = false;
    std::string input = "";

    pos = 1;  // ... auch an Position "mittendrin" parsen
    error_found = false;
    input = "4>3";
    parse_operand(input, pos, error_found);
    REQUIRE(error_found == true || pos != input.length());
    REQUIRE(pos == 1);

    pos = 0;
    error_found = false;
    input = ">3<7";
    parse_operand(input, pos, error_found);
    REQUIRE(error_found == true || pos != input.length());
    REQUIRE(pos == 0);

    pos = 0;
    error_found = false;
    input = "4>";
    parse_operand(input, pos, error_found);
    REQUIRE(error_found == true || pos != input.length());
    // Keine genaue Lokalisation der Fehlerstelle ...
    // REQUIRE(pos == 1);

    // Neue Testfälle ...

    pos = 0;
    error_found = false;
    input = "(4>3";
    parse_operand(input, pos, error_found);
    REQUIRE(error_found == true || pos != input.length());
    // Keine genaue Lokalisation der Fehlerstelle ...
    // REQUIRE(pos == 4);

    pos = 0;
    error_found = false;
    input = "(>3<7)";
    parse_operand(input, pos, error_found);
    REQUIRE(error_found == true || pos != input.length());
    // Keine genaue Lokalisation der Fehlerstelle ...
    // REQUIRE(pos == 2);
}

TEST_CASE("parse_operand() bei leerem Input") {
    std::size_t pos = 0;
    bool error_found = false;

    parse_operand("", pos, error_found);
    REQUIRE(error_found == true);
    REQUIRE(pos == 0);
}

TEST_CASE("parse_operand() veraendert bei korrekt gebildetem Operanden den error_found Indikator nicht") {
    std::size_t pos = 0;
    bool error_found = false;
    std::string input = "(1U2)";

    // Der "input" an sich ist ein korrekter Operand ...
    parse_operand(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == input.length());

    pos = 0;
    error_found = true; // ... sei schon true aus vorherigem fehlgeschlagenen Parsen
    parse_operand(input, pos, error_found);
    REQUIRE(error_found == true);
    REQUIRE(pos == input.length());
}
