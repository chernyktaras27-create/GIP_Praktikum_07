// Datei: test_schritt_1_expect.cpp

#define TEST_FILE test_schritt_1_expect

#include <string>

#include "gip_mini_catch.h"

#include "expect.h"

TEST_CASE("expect() sieht den erwarteten Buchstaben") {
	char expecting = 'a';
	std::string input = "abc";
	std::size_t pos = 0;

	std::cout << "Erwarte den Buchstaben " << expecting
			  << ", bekomme " << input << std::endl;

	bool resultat = expect(expecting, input, pos);

	std::cout << "Resultat ist: "
			  << std::boolalpha << resultat
			  << "\n\n";

    REQUIRE(resultat == true);
    REQUIRE(pos == 0);
}

TEST_CASE("expect() sieht einen anderen als den erwarteten Buchstaben") {
	char expecting = 'a';
	std::string input = "bcd";
	std::size_t pos = 0;

	std::cout << "Erwarte den Buchstaben " << expecting
			  << ", bekomme " << input << std::endl;

	bool resultat = expect(expecting, input, pos);

	std::cout << "Resultat ist: "
			  << std::boolalpha << resultat
			  << "\n\n";

    REQUIRE(resultat == false);
    REQUIRE(pos == 0);
}

TEST_CASE("expect() bei schon leerem Input") {
	char expecting = 'a';
	std::string input = "";
	std::size_t pos = 0;

	std::cout << "Erwarte den Buchstaben " << expecting
			  << ", bekomme " << input << std::endl;

	bool resultat = expect(expecting, input, pos);

	std::cout << "Resultat ist: "
			  << std::boolalpha << resultat
			  << "\n\n";

    REQUIRE(resultat == false);
    REQUIRE(pos == 0);
}
