// Datei: test_schritt_3_parse_number.cpp

#define TEST_FILE test_schritt_3_parse_number

#include <string>

#include "gip_mini_catch.h"

#include "parse_number.h"

TEST_CASE("parse_number() bekommt eine Zahlziffer an der Position") {
    std::size_t pos = 0;
    bool error_found = false;
    std::string input = "";

    pos = 0;
    error_found = false;
    input = "4>3";
    parse_number(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == 1);

    pos = 2; // ... auch Ziffer "mittendrin" muss erkannt werden
    error_found = false;
    input = "4>3<7";
    parse_number(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == 3);

    pos = 2; // ... auch Ziffer "mittendrin" muss erkannt werden
    error_found = false;
    input = "4>3";
    parse_number(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == 3);
}

TEST_CASE("parse_number() bekommt keine Zahlziffer an der Position") {
    std::size_t pos = 0;
    bool error_found = false;
    std::string input = "";

    pos = 1; // ... auch Position "mittendrin" muss geparsed werden können
    error_found = false;
    input = "4>3";
    parse_number(input, pos, error_found);
    REQUIRE(error_found == true);
    REQUIRE(pos == 1);

    pos = 0;
    error_found = false;
    input = ">3<7";
    parse_number(input, pos, error_found);
    REQUIRE(error_found == true);
    REQUIRE(pos == 0);

    pos = 1; // ... auch Position "mittendrin" muss geparsed werden können
    error_found = false;
    input = "4>";
    parse_number(input, pos, error_found);
    REQUIRE(error_found == true);
    REQUIRE(pos == 1);
}

TEST_CASE("parse_number() bei leerem Input") {
    std::size_t pos = 0;
    bool error_found = false;

    parse_number("", pos, error_found);
    REQUIRE(error_found == true);
    REQUIRE(pos == 0);
}

TEST_CASE("parse_number() veraendert bei korrekter Zahlziffer den error_found Indikator nicht") {
    std::size_t pos = 0;
    bool error_found = false;
    std::string input = "4";

    // Der "input" an sich ist eine Number ...
    parse_number(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == input.length());

    pos = 0;
    error_found = true; // ... sei schon true aus vorherigem fehlgeschlagenen Parsen
    parse_number(input, pos, error_found);
    REQUIRE(error_found == true);
    REQUIRE(pos == input.length());
}
