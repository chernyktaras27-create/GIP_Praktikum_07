// Datei: parse_term.h

#pragma once

#include <string>

void parse_term(std::string input, std::size_t &pos, bool &error_found);
