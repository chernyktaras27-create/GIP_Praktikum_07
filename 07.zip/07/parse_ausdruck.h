// Datei: parse_ausdruck.h

#pragma once

#include <string>

void parse_ausdruck(std::string input, std::size_t &pos, bool &error_found);
