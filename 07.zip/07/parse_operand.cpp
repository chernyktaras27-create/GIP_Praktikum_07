// Datei: parse_operand.cpp

#include <iostream>
#include <string>

#include "parse_operand.h"

#include "expect.h"
#include "match.h"
#include "parse_number.h"
#include "parse_ausdruck.h"

void parse_operand(std::string input, std::size_t &pos, bool &error_found)
{
    std::cout << "Betrete parse_operand()" << std::endl;

    if (error_found) {
        std::cout << "Verlasse parse_operand()" << std::endl;
        return;
    }

    // --- Number-Fall ---
    if (pos < input.length() &&
        input[pos] >= '0' && input[pos] <= '9')
    {
        parse_number(input, pos, error_found);
        std::cout << "Verlasse parse_operand()" << std::endl;
        return;
    }

    // Fall 2: '(' Ausdruck ')'
    if (pos < input.length() && input.at(pos) == '(') {
        match('(', input, pos, error_found);
        parse_ausdruck(input, pos, error_found);
        match(')', input, pos, error_found);
        std::cout << "Verlasse parse_operand()" << std::endl;
        return;
    }

    // Fehlerfall
    std::cout << "Fehler: erwarte eine Zahl, aber sehe: ";
    if (pos < input.length()) {
        std::cout << input[pos] << std::endl;
    } else {
        std::cout << "Ende der Eingabe" << std::endl;
    }

    error_found = true;

    std::cout << "Verlasse parse_operand()" << std::endl;
}
