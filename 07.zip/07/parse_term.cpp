// Datei: parse_term.cpp

#include <iostream>
#include <string>

#include "parse_term.h"

#include "expect.h"
#include "match.h"
#include "parse_operand.h"

void parse_term(std::string input, std::size_t &pos, bool &error_found)
{
    std::cout << "Betrete parse_term()" << std::endl;

    

    // Regel: Term ::= Operand
    parse_operand(input, pos, error_found);

    

    std::cout << "Verlasse parse_term()" << std::endl;
}
