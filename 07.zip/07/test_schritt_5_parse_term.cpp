// Datei: test_schritt_5_parse_term.cpp

#define TEST_FILE schritt_5_parse_term

#include <string>

#include "gip_mini_catch.h"

#include "parse_term.h"

TEST_CASE("parse_term() bekommt einen korrekt gebildeten Term") {
    std::size_t pos = 0;
    bool error_found = false;
    std::string input = "";

    pos = 0;
    error_found = false;
    input = "4>3";
    parse_term(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == input.length());

    pos = 0;
    error_found = false;
    input = "4>3<7";
    parse_term(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == input.length());
}

TEST_CASE("parse_term() bekommt einen inkorrekt gebildeten Term") {
    std::size_t pos = 0;
    bool error_found = false;
    std::string input = "";

    pos = 0;
    error_found = false;
    input = "4>";
    parse_term(input, pos, error_found);
    REQUIRE(error_found == true || pos != input.length());
    // Keine genaue Lokalisation der Fehlerstelle ...
    // REQUIRE(pos == 2);

    pos = 0;
    error_found = false;
    input = ">3<7";
    parse_term(input, pos, error_found);
    REQUIRE(error_found == true || pos != input.length());
    // Keine genaue Lokalisation der Fehlerstelle ...
    // REQUIRE(pos == 0);
}

TEST_CASE("parse_term() bei leerem Input") {
    std::size_t pos = 0;
    bool error_found = false;

    parse_term("", pos, error_found);
    REQUIRE(error_found == true);
    REQUIRE(pos == 0);
}

TEST_CASE("parse_term() veraendert bei korrekt gebildetem Term den error_found Indikator nicht") {
    std::size_t pos = 0;
    bool error_found = false;
    std::string input = "4>3";

    // Der "input" an sich ist ein korrekter Term ...
    parse_term(input, pos, error_found);
    REQUIRE(error_found == false);
    REQUIRE(pos == input.length());

    pos = 0;
    error_found = true; // ... sei schon true aus vorherigem fehlgeschlagenen Parsen
    parse_term(input, pos, error_found);
    REQUIRE(error_found == true);
    REQUIRE(pos == input.length());
}
