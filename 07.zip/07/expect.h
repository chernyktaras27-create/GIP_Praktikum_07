// Datei: expect.h

#pragma once

#include <string>

bool expect(char c, std::string input, std::size_t pos);
