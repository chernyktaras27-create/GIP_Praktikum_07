// Datei: parse_number.cpp

#include <iostream>
#include <string>

#include "expect.h"
#include "match.h"

#include "parse_number.h"

void parse_number(std::string input, std::size_t &pos, bool &error_found)
{
    std::cout << "Betrete parse_number()" << std::endl;

    if (error_found) {
        std::cout << "Verlasse parse_number()" << std::endl;
        return;
    }

    // Перевіряємо цифри від 0 до 8
    for (char c = '0'; c <= '8'; c++) {
        if (expect(c, input, pos)) {
            match(c, input, pos, error_found);
            std::cout << "Verlasse parse_number()" << std::endl;
            return;
        }
    }

    // Якщо ніяка з 0–8 не підійшла → пробуємо 9
    match('9', input, pos, error_found);

    std::cout << "Verlasse parse_number()" << std::endl;
}

