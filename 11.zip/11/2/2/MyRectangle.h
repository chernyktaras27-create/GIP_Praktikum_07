#pragma once

#include "MyCanvas.h"

class MyRectangle
{
protected:
    unsigned int x1;
    unsigned int y1;
    unsigned int x2;
    unsigned int y2;
    MyCanvas* canvas_ptr;

public:
    // Конструктор
    MyRectangle(MyCanvas& canvas, unsigned int x1, unsigned int y1, unsigned int x2, unsigned int y2)
        : x1{x1}, y1{y1}, x2{x2}, y2{y2}, canvas_ptr{&canvas} {}

    // Геттери
    unsigned int get_x1() const { return x1; }
    unsigned int get_y1() const { return y1; }
    unsigned int get_x2() const { return x2; }
    unsigned int get_y2() const { return y2; }
    MyCanvas* get_canvas_ptr() const { return canvas_ptr; }

    // Сеттери
    void set_x1(unsigned int val) { x1 = val; }
    void set_y1(unsigned int val) { y1 = val; }
    void set_x2(unsigned int val) { x2 = val; }
    void set_y2(unsigned int val) { y2 = val; }
    void set_canvas_ptr(MyCanvas& canvas) { canvas_ptr = &canvas; }

    // Метод для малювання
    void draw();
};