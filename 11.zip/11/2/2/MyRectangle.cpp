#include "MyRectangle.h"

// draw() викликає метод Canvas для малювання прямокутника
void MyRectangle::draw()
{
    if(canvas_ptr) // перевіряємо, чи вказівник не nullptr
        canvas_ptr->draw_rectangle(x1, y1, x2, y2);
}