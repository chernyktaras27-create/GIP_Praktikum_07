// Datei: MyCanvas.cpp

#include "MyCanvas.h"
#include <iostream>

// Konstruktor
MyCanvas::MyCanvas(unsigned int x, unsigned int y)
    : size_x{x}, size_y{y}, canvas_array_ptr{new char[x * y]}
{
    init();
}

// Copy-Konstruktor
MyCanvas::MyCanvas(const MyCanvas& other)
    : size_x{other.size_x}, size_y{other.size_y},
      canvas_array_ptr{new char[other.size_x * other.size_y]}
{
    for (unsigned int i = 0; i < size_x * size_y; ++i)
        canvas_array_ptr[i] = other.canvas_array_ptr[i];
}

// Zuweisungsoperator
MyCanvas& MyCanvas::operator=(const MyCanvas& other)
{
    if (this == &other)
        return *this;

    delete[] canvas_array_ptr;

    size_x = other.size_x;
    size_y = other.size_y;
    canvas_array_ptr = new char[size_x * size_y];

    for (unsigned int i = 0; i < size_x * size_y; ++i)
        canvas_array_ptr[i] = other.canvas_array_ptr[i];

    return *this;
}

// Destruktor
MyCanvas::~MyCanvas()
{
    delete[] canvas_array_ptr;
}

// Getter / Setter
unsigned int MyCanvas::get_size_x() const
{
    return size_x;
}

unsigned int MyCanvas::get_size_y() const
{
    return size_y;
}

char* MyCanvas::get_canvas_array_ptr() const
{
    return canvas_array_ptr;
}

void MyCanvas::set_size_x(unsigned int x)
{
    size_x = x;
}

void MyCanvas::set_size_y(unsigned int y)
{
    size_y = y;
}

void MyCanvas::set_canvas_array_ptr(char* array_ptr)
{
    canvas_array_ptr = array_ptr;
}

// Initialisierung
void MyCanvas::init()
{
    for (unsigned int y = 0; y < size_y; ++y)
        for (unsigned int x = 0; x < size_x; ++x)
            canvas_array_ptr[y * size_x + x] = '.';
}

// Canvas-Methoden
void MyCanvas::set(unsigned int x, unsigned int y, char c)
{
    canvas_array_ptr[y * size_x + x] = c;
}

char MyCanvas::get(unsigned int x, unsigned int y) const
{
    return canvas_array_ptr[y * size_x + x];
}

std::string MyCanvas::to_string() const
{
    std::string result;

    for (unsigned int y = 0; y < size_y; ++y)
    {
        for (unsigned int x = 0; x < size_x; ++x)
            result += canvas_array_ptr[y * size_x + x];

        result += '\n';
    }

    return result;
}

void MyCanvas::print() const
{
    std::cout << to_string() << std::endl;
}

void MyCanvas::draw_rectangle(unsigned int x1, unsigned int y1, unsigned int x2, unsigned int y2)
    {
        // обходимо усі рядки та колонки
        for(unsigned int y = y1; y <= y2 && y < size_y; ++y)
        {
            for(unsigned int x = x1; x <= x2 && x < size_x; ++x)
            {
                canvas_array_ptr[y * size_x + x] = '#';
            }
        }
    }