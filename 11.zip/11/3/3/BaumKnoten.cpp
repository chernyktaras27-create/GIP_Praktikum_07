#include "BaumKnoten.h"
#include <iostream>

void BaumKnoten::ausgeben(unsigned int tiefe) const
{
    if(rechts) 
        rechts->ausgeben(tiefe + 2);

    for(unsigned int i = 0; i < tiefe; ++i)
        std::cout << "+";

    std::cout << data << std::endl;

    if(links) 
        links->ausgeben(tiefe + 2);
}