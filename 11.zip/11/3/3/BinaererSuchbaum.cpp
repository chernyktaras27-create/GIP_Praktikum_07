#include "BinaererSuchbaum.h"
#include <iostream>

// Вставка значення у дерево
void BinaererSuchbaum::einfuegen(int wert)
{
    if(!root) 
    {
        root = new BaumKnoten(wert);
        return;
    }

    BaumKnoten* aktuell = root;
    while(true)
    {
        if(wert < aktuell->get_data())
        {
            if(aktuell->get_links())
                aktuell = aktuell->get_links();
            else
            {
                aktuell->set_links(new BaumKnoten(wert));
                break;
            }
        }
        else if(wert > aktuell->get_data())
        {
            if(aktuell->get_rechts())
                aktuell = aktuell->get_rechts();
            else
            {
                aktuell->set_rechts(new BaumKnoten(wert));
                break;
            }
        }
        else
        {
            // Значення вже існує, не вставляємо дублікат
            break;
        }
    }
}

// Друк дерева
void BinaererSuchbaum::ausgeben() const
{
    if(root)
        root->ausgeben(0);
    else
        std::cout << "Leerer Baum." << std::endl;
}