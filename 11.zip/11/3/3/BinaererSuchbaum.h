#pragma once
#include "BaumKnoten.h"

class BinaererSuchbaum
{
private:
    BaumKnoten* root;   // Корінь дерева

public:
    BinaererSuchbaum() : root{nullptr} {}

    // Геттер для кореня
    BaumKnoten* get_root() const { return root; }

    // Прототипи методів
    void einfuegen(int wert);
    void ausgeben() const;
};