#pragma once

class BaumKnoten
{
private:
    int data;                 // Значення вузла
    BaumKnoten* links;        // Лівий нащадок
    BaumKnoten* rechts;       // Правий нащадок

public:
    // Конструктор
    BaumKnoten(int wert, BaumKnoten* l = nullptr, BaumKnoten* r = nullptr)
        : data{wert}, links{l}, rechts{r} {}

    // Геттери
    int get_data() const { return data; }
    BaumKnoten* get_links() const { return links; }
    BaumKnoten* get_rechts() const { return rechts; }

    // Сеттери
    void set_data(int wert) { data = wert; }
    void set_links(BaumKnoten* l) { links = l; }
    void set_rechts(BaumKnoten* r) { rechts = r; }

    // Прототип методу для друку
    void ausgeben(unsigned int tiefe) const;
};