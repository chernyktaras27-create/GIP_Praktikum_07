// Datei: liste.h

#pragma once

#include <string>

struct TListenKnoten
{
    int data;
    TListenKnoten *next;
    TListenKnoten *prev;
};

std::string liste_als_string(TListenKnoten* anker);

void hinten_anfuegen(TListenKnoten*& anker, const int wert);
//09.02
std::string liste_als_string_rueckwaerts(TListenKnoten* anker);
//09.03
void in_liste_einfuegen(TListenKnoten*& anker, const int wert, const int vor_wert);

//09.04
void aus_liste_loeschen(TListenKnoten*& anker, const int wert);
