// Datei: liste.cpp

#include <string>
#include "liste.h"

std::string liste_als_string(TListenKnoten* anker)
{
    std::string resultat = "";

    if (anker == nullptr) {
        return "Leere Liste.";
    }
    else
    {
        resultat += "[ ";
        TListenKnoten* ptr = anker;
        do
        {
            resultat += std::to_string(ptr->data);

            if (ptr->next != nullptr) { resultat += " , "; }
            else { resultat += " "; }

            ptr = ptr->next;
        } while (ptr != nullptr);
        resultat += "]";
    }
    return resultat;
}

// Wird modifiziert in Aufgabe INF-09.01 ...
void hinten_anfuegen(TListenKnoten *&anker, const int wert)
{
    TListenKnoten *neuer_eintrag = new TListenKnoten;
    neuer_eintrag->data = wert;
    neuer_eintrag->next = nullptr;
    neuer_eintrag->prev = nullptr;

    if (anker == nullptr) {
        anker = neuer_eintrag;
    }
    else
    {
        TListenKnoten *ptr = anker;
        while (ptr->next != nullptr) {
            ptr = ptr->next;
        }
        ptr->next = neuer_eintrag;
        neuer_eintrag->prev = ptr;
    }
}

// 09.02 – строка у зворотньому напрямку

std::string liste_als_string_rueckwaerts(TListenKnoten* anker)
{
    if (anker == nullptr) return "Leere Liste.";

    // йдемо до кінця
    TListenKnoten* ptr = anker;
    while (ptr->next != nullptr) {
        ptr = ptr->next;
    }

    std::string s = "[ ";
    // рухаємося назад
    while (ptr != nullptr)
    {
        s += std::to_string(ptr->data);
        if (ptr->prev != nullptr) s += " , ";
        else s += " ";
        ptr = ptr->prev;
    }
    s += "]";
    return s;
}

//09.03 – вставити ПЕРЕД vor_wert

void in_liste_einfuegen(TListenKnoten*& anker, const int wert, const int vor_wert)
{
    TListenKnoten* neu = new TListenKnoten;
    neu->data = wert;
    neu->next = nullptr;
    neu->prev = nullptr;

    // якщо список порожній
    if (anker == nullptr) {
        anker = neu;
        return;
    }

    TListenKnoten* ptr = anker;

    // знайти перший елемент із data == vor_wert
    while (ptr != nullptr && ptr->data != vor_wert) {
        ptr = ptr->next;
    }

    // якщо НЕ знайдено — додаємо в кінець
    if (ptr == nullptr) {
        hinten_anfuegen(anker, wert);
        delete neu; // бо hinten_anfuegen створює свій new
        return;
    }

    // якщо потрібно вставити перед анкером
    if (ptr == anker) {
        neu->next = anker;
        anker->prev = neu;
        anker = neu;
        return;
    }

    // вставка в середину
    neu->next = ptr;
    neu->prev = ptr->prev;

    ptr->prev->next = neu;
    ptr->prev = neu;
}

// 09.04 – видалити перший вузол із заданим значенням
void aus_liste_loeschen(TListenKnoten*& anker, const int wert)
{
    if (anker == nullptr) return;

    TListenKnoten* ptr = anker;

    // знайти потрібний вузол
    while (ptr != nullptr && ptr->data != wert) {
        ptr = ptr->next;
    }

    if (ptr == nullptr) return; // не знайдено

    // видалення голови
    if (ptr == anker) {
        anker = ptr->next;
        if (anker != nullptr) anker->prev = nullptr;
        delete ptr;
        return;
    }

    // середина або кінець
    if (ptr->prev != nullptr) ptr->prev->next = ptr->next;
    if (ptr->next != nullptr) ptr->next->prev = ptr->prev;

    delete ptr;
}