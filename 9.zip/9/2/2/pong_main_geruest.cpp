#define CIMGGIP_MAIN 
#include "CImgGIP08.h" 
 
int main() 
{ 
    // Für das "blaue Spielfeld" ... 
    const unsigned int x0 = 100, y0 = 100; 
    const unsigned int x1 = 500, y1 = 500; 
    // Für Position und Ausdehnung des weißen Balls ... 
    unsigned int xb = 200, yb = 300; 
    const unsigned int ball_size = 10; 
    // Geschwindigkeit des Balls ... 
    int delta_x = -3, delta_y = -3; 
    // Ausdehnung und Position des Schlaegers ... 
    const unsigned int schlaeger_size_x = 50, schlaeger_size_y = 20; 
    unsigned int xs = 300, ys = y1 - schlaeger_size_y; 
 
    gip_white_background(); 
    while (gip_window_not_closed()) 
    { 
       gip_stop_updates();

        // --- Spielfeld (blau) ---
        gip_draw_rectangle(x0, y0, x1, y1, blue);

        // --- Ball (weiß) ---
        gip_draw_rectangle(xb, yb, xb + ball_size, yb + ball_size,
                           white);

        // --- Schläger (weiß) ---
        gip_draw_rectangle(xs, ys,
                           xs + schlaeger_size_x,
                           ys + schlaeger_size_y,
                           white);

        // --- Schläger folgt Maus ---
        unsigned int maus_x = gip_mouse_x();
        xs = maus_x - schlaeger_size_x / 2;

        // Begrenzung
        if (xs < x0) xs = x0;
        if (xs + schlaeger_size_x > x1) xs = x1 - schlaeger_size_x;

        // --- Kollisionen Wände ---
        if (yb <= y0)
            delta_y = -delta_y;

        if (xb <= x0)
            delta_x = -delta_x;

        if (xb + ball_size >= x1)
            delta_x = -delta_x;

        // --- Kollision Schläger ---
        bool trifft_schlaeger =
            (yb + ball_size >= ys) &&
            (yb + ball_size <= ys + schlaeger_size_y) &&
            (xb + ball_size >= xs) &&
            (xb <= xs + schlaeger_size_x);

        if (trifft_schlaeger)
            delta_y = -delta_y;

        // --- Unterer Rand => Spiel beenden (kein close_window notwendig!) ---
        if (yb + ball_size > y1)
            break;   // ← вихід із циклу, вікно саме закриється

        // --- Ball bewegen ---
        xb += delta_x;
        yb += delta_y;

        gip_start_updates();
    
        gip_wait(50); 
    } 
    return 0; 
}