
#include <string>
#include "text_funktionen.h"

std::string br(std::string s){
    return s + "<br/>";

}

std::string b(std::string s){
    return "<b>" + s + "</b>";
}
void spalte_ab_erstem(char trenner, std::string eingabe,std::string &vor, std::string &rest)
{
    vor = "";
    rest = "";

    bool gefunden = false;

    for (size_t i = 0; i < eingabe.length(); i++)
    {
        if (!gefunden && eingabe[i] == trenner)
        {
            gefunden = true;
        }
        else if (!gefunden)
        {
            vor += eingabe[i];
        }
        else
        {
            rest += eingabe[i];
        }
    }
}
std::string trimme(std::string s)
{
    if (s == "")
        return s;

    // 1. знайти перший непробіл
    int start = 0;
    while (start < s.length() && s[start] == ' ')
    {
        start++;
    }

    // 2. знайти останній непробіл
    int end = s.length() - 1;
    while (end > start && s[end] == ' ')
    {
        end--;
    }

    // 3. самі збираємо новий рядок
    std::string result = "";
    for (int i = start; i <= end; i++)
    {
        result += s[i];
    }

    return result;
}
std::string ersetze(std::string s, char key, const std::string &ersetzenMit) {
    std::string result = "";
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == key) {
            result += ersetzenMit;
        } else {
            result += s[i];
        }
    }
    return result;
}