// Datei: test_spalte_ab_erstem.cpp

#define TEST_FILE test_spalte_ab_erstem

#include <string>

#include "gip_mini_catch.h"

#include "text_funktionen.h"


TEST_CASE("spalte_ab_erstem() bei leerer Eingabe") {
    // Teste auch, dass alte Inhalte von s1 und s2 mit den neuen Werten
    // überschrieben werden ...
    std::string s1 = "Wert von s1 vor Aufruf der Funktion", 
                s2 = "Wert von s2 vor Aufruf der Funktion";

    spalte_ab_erstem('x', "", s1, s2);

    REQUIRE( s1 == "" && s2 == "" );
}

TEST_CASE("spalte_ab_erstem() bei nicht-leerer Eingabe") {
    // Teste auch, dass alte Inhalte von s1 und s2 mit den neuen Werten
    // überschrieben werden ...
    std::string s1 = "Wert von s1 vor Aufruf der Funktion", 
                s2 = "Wert von s2 vor Aufruf der Funktion";

    spalte_ab_erstem('c', "12 abcdecxy 89", s1, s2);

    REQUIRE( s1 == "12 ab" && s2 == "decxy 89" );
}

TEST_CASE("spalte_ab_erstem() bei nicht-leerer Eingabe") {
    // Teste auch, dass alte Inhalte von s1 und s2 mit den neuen Werten
    // überschrieben werden ...
    std::string s1 = "Wert von s1 vor Aufruf der Funktion", 
                s2 = "Wert von s2 vor Aufruf der Funktion";

    spalte_ab_erstem('a', "aaa aaa", s1, s2);

    REQUIRE( s1 == "" && s2 == "aa aaa" );
}

TEST_CASE("spalte_ab_erstem() bei nicht-leerer Eingabe") {
    // Teste auch, dass alte Inhalte von s1 und s2 mit den neuen Werten
    // überschrieben werden ...
    std::string s1 = "Wert von s1 vor Aufruf der Funktion", 
                s2 = "Wert von s2 vor Aufruf der Funktion";

    spalte_ab_erstem('a', "123 456", s1, s2);

    REQUIRE( s1 == "123 456" && s2 == "" );
}

