// Datei: webseite_main.cpp

#include <iostream>
#include <string>
#include <fstream>

#define CATCH_CONFIG_RUNNER
#include "gip_mini_catch.h"

#include "text_funktionen.h"
#include "person.h"

int main()
{
    Catch::Session().run();

    std::ifstream datei("personendaten.txt");
    std::string eingabezeile, kurztext = "", langtext = "";

    // Datei lesen
    while (std::getline(datei, eingabezeile)) {
        Person person = extrahiere_person(eingabezeile);

        kurztext += br(b(person.nachname) + ", " + person.vorname) + "\n";

        langtext += br(
                        b(person.vorname + " " + person.nachname) +
                        ", " +
                        person.geburtsdatum
                     ) + "\n";
    }
    datei.close();

    // Template lesen und neue Datei erzeugen
    std::ifstream tmpl("webseite.html.tmpl");
    std::ofstream out("webseite.html");

    while (std::getline(tmpl, eingabezeile)) {
        eingabezeile = ersetze(eingabezeile, '%', kurztext);
        eingabezeile = ersetze(eingabezeile, '$', langtext);
        out << eingabezeile << "\n";
    }

    tmpl.close();
    out.close();

    system("PAUSE");
    return 0;
}
