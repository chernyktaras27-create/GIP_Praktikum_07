// Datei: test_trimme.cpp

#define TEST_FILE test_trimme

#include <string>

#include "gip_mini_catch.h"

#include "text_funktionen.h"

TEST_CASE("trimme() bei leerer Eingabe") {
    REQUIRE( trimme("") == std::string("") );
}

// In den Offline-Aufgaben mussten Pluszeichen weg-getrimmt werden.
// Jetzt soll dies auf Leerzeichen geändert sein!
TEST_CASE("trimme() bei nicht-leerer Eingabe, Pluszeichen nicht trimmen") {
    std::string s = "++abc++";
    REQUIRE( trimme(s) == s );
}

TEST_CASE("trimme() bei nicht-leerer Eingabe, nur Leerzeichen") {
    REQUIRE( trimme("     ") == std::string("") );
}

TEST_CASE("trimme() bei nicht-leerer Eingabe, ein Leerzeichen am Anfang") {
    REQUIRE( trimme(" abc") == std::string("abc") );
}

TEST_CASE("trimme() bei nicht-leerer Eingabe, mehrere Leerzeichen am Anfang") {
    REQUIRE( trimme("   abc") == std::string("abc") );
}

TEST_CASE("trimme() bei nicht-leerer Eingabe, ein Leerzeichen am Ende") {
    REQUIRE( trimme("abc ") == std::string("abc") );
}

TEST_CASE("trimme() bei nicht-leerer Eingabe, mehrere Leerzeichen am Ende") {
    REQUIRE( trimme("abc    ") == std::string("abc") );
}

TEST_CASE("trimme() bei nicht-leerer Eingabe, Leerzeichen am Anfang und Ende") {
    REQUIRE( trimme("  abc    ") == std::string("abc") );
}
