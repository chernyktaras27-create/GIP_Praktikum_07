
#include <string>

std::string br(std::string s);
std::string b(std::string s);
void spalte_ab_erstem(char trenner, std::string eingabe,std::string &vor, std::string &rest);
std::string trimme(std::string s);
std::string ersetze(std::string s, char key, const std::string &ersetzenMit);