#include "MyFramedRectangle.h"

// Конструктор: викликаємо конструктор базового класу
MyFramedRectangle::MyFramedRectangle(MyCanvas& canvas,
                                     unsigned int x1,
                                     unsigned int y1,
                                     unsigned int x2,
                                     unsigned int y2)
    : MyRectangle(canvas, x1, y1, x2, y2)
{
}

// Малювання прямокутника з рамкою
void MyFramedRectangle::draw()
{
    // 1. Малюємо звичайний заповнений прямокутник з #
    MyRectangle::draw();

    // 2. Верхня і нижня рамка
    for (unsigned int x = x1; x <= x2; ++x)
    {
        canvas_ptr->set_pixel(x, y1, '+'); // верх
        canvas_ptr->set_pixel(x, y2, '+'); // низ
    }

    // 3. Ліва і права рамка
    for (unsigned int y = y1; y <= y2; ++y)
    {
        canvas_ptr->set_pixel(x1, y, '+'); // ліва сторона
        canvas_ptr->set_pixel(x2, y, '+'); // права сторона
    }
}