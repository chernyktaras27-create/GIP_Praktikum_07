// Datei: tupel.cpp

#include "tupel.h"

// Реалізація шаблонної функції vergleiche
template<typename T1, typename T2>
int vergleiche(const Tupel<T1, T2>& p1, const Tupel<T1, T2>& p2)
{
    if (p1.komponente1 < p2.komponente1 && p1.komponente2 < p2.komponente2)
        return -1;

    if (p1.komponente1 > p2.komponente1 && p1.komponente2 > p2.komponente2)
        return 1;

    return 0;
}

// -------------------------------
// ЯВНА ІНСТАНЦІАЦІЯ ШАБЛОНІВ
// -------------------------------

// Tupel<std::string, int>
template struct Tupel<std::string, int>;

// Tupel<int, int>
template struct Tupel<int, int>;

// vergleiche<std::string, int>
template int vergleiche<std::string, int>(
    const Tupel<std::string, int>&,
    const Tupel<std::string, int>&
);

// vergleiche<int, int>
template int vergleiche<int, int>(
    const Tupel<int, int>&,
    const Tupel<int, int>&
);