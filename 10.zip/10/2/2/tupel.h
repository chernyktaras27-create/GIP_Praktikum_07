#ifndef TUPEL_H
#define TUPEL_H

#include <string>

// Оголошення шаблонної структури Tupel
template<typename T1, typename T2>
struct Tupel
{
    T1 komponente1;
    T2 komponente2;
};

// Оголошення шаблонної функції vergleiche
template<typename T1, typename T2>
int vergleiche(const Tupel<T1, T2>& p1, const Tupel<T1, T2>& p2);

#endif