// Datei: binaerer_suchbaum.h

#ifndef BINAERER_SUCHBAUM_H
#define BINAERER_SUCHBAUM_H

namespace suchbaum {

struct BaumKnoten {
    int data;
    BaumKnoten* links;
    BaumKnoten* rechts;
};

void einfuegen(BaumKnoten*& anker, int wert);
void ausgeben(BaumKnoten* anker);

// rekursive Hilfsfunktion
void knoten_ausgeben(BaumKnoten* knoten, unsigned int tiefe);

}

#endif