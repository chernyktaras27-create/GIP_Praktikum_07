#include <iostream>
#include "binaerer_suchbaum.h"

namespace suchbaum {

// -----------------------------------------------------
// Helferfunktion zum rekursiven Ausgeben der Knoten
// -----------------------------------------------------
void knoten_ausgeben(BaumKnoten* knoten, unsigned int tiefe)
{
    if (knoten == nullptr) {
        return;
    }

    // Zuerst rechten Teilbaum ausgeben
    knoten_ausgeben(knoten->rechts, tiefe + 1);

    // Einrückung: pro Tiefe zwei Pluszeichen
    for (unsigned int i = 0; i < tiefe; i++) {
        std::cout << "++";
    }

    // Daten ausgeben
    std::cout << knoten->data << std::endl;

    // Dann linken Teilbaum ausgeben
    knoten_ausgeben(knoten->links, tiefe + 1);
}

// -----------------------------------------------------
// Ausgeben des Baumes (Wrapper)
// -----------------------------------------------------
void ausgeben(BaumKnoten* anker)
{
    if (anker == nullptr) {
        std::cout << "Leerer Baum." << std::endl;
    } else {
        knoten_ausgeben(anker, 0);
    }
}

// -----------------------------------------------------
// Einfügen eines neuen Wertes
// -----------------------------------------------------
void einfuegen(BaumKnoten*& anker, int wert)
{
    // Wenn der Baum leer ist → neuen Wurzelknoten erzeugen
    if (anker == nullptr) {
        anker = new BaumKnoten{wert, nullptr, nullptr};
        return;
    }

    // Vergleich mit der Wurzel
    if (wert == anker->data) {
        // Duplikat → nichts tun
        return;
    } 
    else if (wert < anker->data) {
        // links einfügen
        if (anker->links == nullptr) {
            anker->links = new BaumKnoten{wert, nullptr, nullptr};
        } else {
            einfuegen(anker->links, wert);
        }
    }
    else {
        // rechts einfügen
        if (anker->rechts == nullptr) {
            anker->rechts = new BaumKnoten{wert, nullptr, nullptr};
        } else {
            einfuegen(anker->rechts, wert);
        }
    }
}

} // namespace suchbaum